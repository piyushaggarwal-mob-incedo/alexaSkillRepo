
var skillCreation = require("./skill-creation");
var skillUpdation = require("./skill-updation");
var oAuthLinking  = require("./oauth-linking");
var input;

var successResponse = {
	"modelUpdation" : {
		"status" : "failed",
		"message" : " ",
		"resultMsg" : " "
	}
};


var skillUpdationrequest = {
    "skillName": "Hoichoi",
    "invocationName": "Hoichoi",
    "skillDescription": "Bengali Songs and Collection",
    "type": "entertainment",
    "skill-created": "no",
    "app-id": "7fa0ea9a-9799-4417-99f5-cbb5343c551d",
    "accountInfo": {
        "vendorId": "M2L5M4R746DKO0",
        "skillRefreshToken": "Atzr|IwEBIG-7F6WNHRrokQuF2p6EH4fgcdQCUkmz-hE_K1Oq60Mhj4HJgYi3hsx57p71Gnsz24q_02JuXb-STtX7-8XtmElPgQhn8l7ye_WLtieR8FdDl-FNOwixYLChlsiHPG1xT5vsAUWCesTlwQBUyqqdYRsLUE8jPFldfMeu87yTen6fHiEWUiOR90APrfno87WUaDYWOw7VJH6zcinYWMBCTn1q1uir0IO4slIXesGPfqxpJdXr1ODE06VWP95N57yKRqnY6-6kXvJ2d0u70fTGCLDg7ChspqWJ4olG1bMYIXk-1Ps8CuuQRr3aOeB1H1sApC2xBxQ-P4AlJDxnTj_SR58MxBXU3F5Qwhto7jU6n-uoquRGrnAyTzF2Lah5UwMKZGiQaH0B7DNqwVE_OCC1X08v4GL3yinhJqsZYaT1v77RuAmVTK677QOkMAoped1eyP5T1w9hmFbC7QC1QhEhcFePKSB_eBo_a-KWbiEF0sR5wATXC2fL-LzoqFv21YgMg2kmvYBsIMoxXUGwP1XV-Ut05lYQ2SWmPpmsO6B6_NsFs4ou_Dx-QcCkWIdCUutL2_XKD4SHc5uugK9wwbS9LNST8O3pMX_RncftlODKfZH2QQ",
        "clientId": "amzn1.application-oa2-client.42e0b68af9e64752be7c03131da08e63",
        "clientSecret": "e347dc1fdc5154fd50bb5713e689df76960de08398a4cc88839e0980f292ab0c",
        "awsLambdaUrl": "arn:aws:lambda:us-east-1:993995185795:function:appcms"
    },
    "accountLinkingInfo": {
        "clientId": "hoichoi-tv",
        "clientSecret": "f17a7c2c2e27433c902e2f6c09341c64",
        "tokenUrl": "",
        "authorizationUrl": ""
    },
    "intentsList": [
        {
            "name": "GetNew",
            "samples": [
                "Tell me whats fresh",
                "Tell me whats new",
                "Tell me some new movies",
                "What do you have for me",
                "What's New",
                "What are some latest videos",
                "Show Me Latest Content",
                "Latest Videos"
            ]
        },
        {
            "name": "GetPopular",
            "samples": [
                "Tell me whats popular",
                "What are people excited about",
                "Whats new and exciting",
                "List popular movies"
            ]
        },
        {
            "name": "DescribeContent",
            "samples": [
                "Can you describe {videoname}",
                "Describe {videoname}",
                "can you give me details about {videoname}",
                "tell me about {videoname}"
            ]
        },
        {
            "name": "GetWatchlist",
            "samples": [
                "Whats in my list",
                "Whats in my queue",
                "Whats in my watchlist",
                "get watch list",
                "get my watch  list",
                "get my short listed videos",
                "items in watch list",
                "watchlist",
                "show watch  list",
                "list my watch list",
                "Get my Watchlist"
            ]
        },
        {
            "name": "CategorySearch",
            "samples": [
                "What are some good {category} movies",
                "Recommend some {category} movies",
                "Please tell some good {category} movies"
            ]
        },
        {
            "name": "AddToWatchList",
            "samples": [
                "Add {videoname} to watchlist",
                "Please Add {videoname} to watchlist"
            ]
        },
        {
            "name": "NextBillingDate",
            "samples": [
                "When is my next billing date",
                "Am I subscribed",
                "when will my subscription end",
                "next billing date",
                "what is my next billing date"
            ]
        },
        {
            "name": "AMAZON.PauseIntent",
            "samples": []
        },
        {
            "name": "AMAZON.ResumeIntent",
            "samples": []
        },
        {
            "name": "AMAZON.StopIntent",
            "samples": []
        }
    ]
};

    
	
exports.handler = (event, context, callback) => {

	var skillJsonUrl = event.skillCreateUrl;
	var mySkillId = event.skillId;
	

	var mySkillId = "amzn1.ask.skill.04a82f8e-57be-4d9f-aefc-6602a7dc1157";

    skillCreation.getSkillCreateJson(skillJsonUrl)
		.then(function(result){
			input = JSON.parse(result);
			console.log(input);
			console.log(input.accountInfo.skillRefreshToken);
			return skillCreation.getAccessToken(input.accountInfo.skillRefreshToken, input.accountInfo.clientId, input.accountInfo.clientSecret);
		})
		.then(function(result){
		  console.log(result);	
		  result = JSON.parse(result);
		  //console.log(result.access_token);
		  return skillUpdation.updateSkill(mySkillId, input ,result.access_token);
		})
		.then(function (result) {
			console.log("Model Updated Successfully");
			console.log("Success");
			successResponse.modelUpdation.status="Success";
			successResponse.modelUpdation.message = "Model Updation Done Succesfully";
			successResponse.modelUpdation.resultMsg = result;
			console.log(successResponse);
			callback(null, successResponse);
		})
		.catch(function(error){
			successResponse.modelUpdation.status="Failed";
			successResponse.modelUpdation.message = error;
		    console.log(error);
		    callback(null, successResponse);
		});

	
};




  