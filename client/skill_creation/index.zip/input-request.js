
var skillCreation = require("./skill-creation");
var skillUpdation = require("./skill-updation");
var oAuthLinking  = require("./oauth-linking");
var input;

exports.handler = (event, context, callback) => {
    // TODO implement
    console.log(event);
    var skillUrl = event.myJsonUrl;
    callback(null, event);
};

var skillCreateInitiate = function(skillJsonUrl){
	skillCreation.getSkillCreateJson(skillJsonUrl)
		.then(function(result){
			input = JSON.parse(result);
			console.log(input);
			return skillCreation.getAccessToken(input.accountInfo.skillRefreshToken, input.accountInfo.clientId, input.accountInfo.clientSecret);
		})
		.then(function(result){
		  result = JSON.parse(result);
		  //console.log(result.access_token);
		  return skillCreation.createSkill(input,result.access_token);
		})
		.then(function(result){
		  var mySkillId = result.skillId;
		  //console.log(result.access_token);
		  console.log("Skill Succesfully created with Skill ID" + mySkillId);
		  console.log("Building Interaction Model .....");
		  return skillUpdation.updateSkill(mySkillId, input, result.access_token);
		})
		.then(function(result){
		   //console.log(result);
		   console.log("Interaction Model Succesfully Built");
		   console.log("Linking Oauth2 with the" + " " +input.skillName);
		   return oAuthLinking.updateOAuthLinking(input, result.access_token, result.mySkillID)
		})
		.then(function (result) {
			console.log("Oauth2 Succesfully Linked with " + " " + input.skillName);
			console.log("Automation Test Cases Successfully Built");
			console.log("Success");
			callback(null, "skillSuccess");
		})
		.catch(function(error){
		  console.log(error);
		});
}



  