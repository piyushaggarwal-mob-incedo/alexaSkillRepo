var amazonConfig = {
	"amazonTokenUrl" : "https://api.amazon.com/auth/o2/token/",
	"amazonSkillBaseUrl" : "https://api.amazonalexa.com/v0/skills/",
	"getTheSkillCreateJson" : "https://91w08raymd.execute-api.us-east-1.amazonaws.com/first"
}

module.exports.amazonConfig = amazonConfig;


